import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SearchserviceService {
  searchURL="http://localhost:3000/user/search";
  constructor(private http:HttpClient) { }
  search(): Observable<any> {
    return <Observable<any>> this.http.get(this.searchURL);
  }
  
}
